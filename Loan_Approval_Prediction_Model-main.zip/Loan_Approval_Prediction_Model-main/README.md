# Loan_Approval_Prediction_Model
Project to deploy Heroku and flask
